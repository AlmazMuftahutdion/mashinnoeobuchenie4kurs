import os

from flask import Flask, jsonify, request
from teachable_machine import TeachableMachine
from tensorflow import keras

keras.utils.disable_interactive_logging()

MODEL_PATH = "keras_model.h5"
LABELS_PATH = "labels.txt"
PORT = 5055

app = Flask(__name__)
app.json.ensure_ascii = False

model = TeachableMachine(model_path=MODEL_PATH, labels_file_path=LABELS_PATH)

labels = []
for line in open(LABELS_PATH, "r", encoding="utf-8"):
    labels.append(line.strip().split(" ", 1))

class_names = []
for index, name in labels:
    class_names.append(name)


def make_answer(image_path):
    result = model.classify_image(image_path)
    index = int(result["class_index"])

    predictions = []
    for i in range(len(class_names)):
        predictions.append({
            "class": class_names[i],
            "probability": round(float(result["predictions"][i]), 4),
        })

    return {
        "class": class_names[index],
        "class_index": index,
        "confidence": round(float(result["class_confidence"]), 4),
        "confidence_percent": round(float(result["class_confidence"]) * 100, 1),
        "predictions": predictions,
    }


@app.get("/")
def start_page():
    return jsonify({
        "model": "обувь",
        "classes": class_names,
        "get": "/predict?path=sneakers_test/images (5).jpg",
        "post": "/predict, картинка в поле file",
    })


@app.get("/predict")
def predict_by_path():
    path = request.args.get("path", "")

    if not os.path.exists(path):
        return jsonify({"error": "файл не найден", "path": path}), 404

    return jsonify(make_answer(path))


@app.post("/predict")
def predict_by_file():
    file = request.files.get("file")

    if file is None:
        return jsonify({"error": "нет файла в поле file"}), 400

    temp_path = "upload_temp.jpg"
    file.save(temp_path)
    answer = make_answer(temp_path)
    os.remove(temp_path)

    return jsonify(answer)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, threaded=True)
