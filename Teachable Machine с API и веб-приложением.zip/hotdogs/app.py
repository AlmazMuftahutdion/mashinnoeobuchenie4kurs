import requests
import streamlit as st

API = "http://127.0.0.1:5055"

st.title("Распознавание обуви")
st.write("Модель из задания 2: кроссовки, ботинки, туфли. Ответ приходит по API.")

left, right = st.columns([1, 1])

with left:
    file = st.file_uploader("Добавить фотографию", type=["jpg", "jpeg", "png"])

    if file is not None:
        st.image(file)

    pressed = st.button("Сделать прогноз")

with right:
    box = st.container(height=380)

    if pressed:
        if file is None:
            box.write("Сначала добавь фотографию слева.")
        else:
            try:
                response = requests.post(API + "/predict", files={"file": file.getvalue()})
                data = response.json()
            except Exception:
                data = {"error": "API не отвечает. Запусти python api.py"}

            if "error" in data:
                box.write(data["error"])
            else:
                text = "### Ответ\n\n"
                text += "Класс: **" + str(data["class"]) + "**\n\n"
                text += "Точность: **" + str(data["confidence_percent"]) + "%**\n\n"
                text += "Очки по всем классам:\n\n"

                for item in data["predictions"]:
                    text += "   " + item["class"] + " - " + str(item["probability"]) + "\n\n"

                box.markdown(text)
    else:
        box.write("Ответ...")

st.divider()
