"""Быстрые проверки: python test_recsys.py  (работает на копии БД, исходную не трогает)"""
import os, shutil, tempfile
from recsys import Recommender, NotEnoughData

tmp = os.path.join(tempfile.mkdtemp(), "t.db")
shutil.copy(os.path.join("data", "films.db"), tmp)
rs = Recommender(tmp)

pop = rs.popular(10);                     assert len(pop) == 10
assert len(rs.popular(10, genre="Comedy")) == 10
m = rs.search("Toy Story")[0];            print("поиск:", m["title"])
assert len(rs.similar_cf(m["movie_id"])) == 10
assert len(rs.similar_content(m["movie_id"])) == 10
assert len(rs.recommend_user_cf(1)) == 10
p = rs.recommend_personal(1);             assert p["method"] == "content" and len(p["items"]) == 10 and p["items"][0]["because"]
assert rs.recommend_personal(1, method="hybrid")["method"] == "hybrid"

# новый пользователь: сначала популярные, после оценок - персональные
u = rs.create_user("Тест")["user_id"]
assert rs.recommend_personal(u)["method"] == "popular"
try: rs.recommend_user_cf(u); raise SystemExit("ожидалась ошибка")
except NotEnoughData: pass
before = len(rs.ratings) if hasattr(rs, "ratings") else 0
for t, r in [("Matrix, The", 5), ("Inception", 5), ("Interstellar", 4.5), ("Titanic", 2)]:
    rs.add_rating(u, rs.search(t)[0]["movie_id"], r)
p = rs.recommend_personal(u)
assert p["method"] == "content" and len(p["items"]) == 10
seen = set(rs.user_ratings(u))
assert not seen & {x["movie_id"] for x in p["items"]}, "уже оценённые не рекомендуются"
print("рекомендации новому:", [x["title"] for x in p["items"][:5]])

# обновление оценки, а не дубль
mid = rs.search("Titanic")[0]["movie_id"]
rs.add_rating(u, mid, 4)
assert rs.user_ratings(u)[mid] == 4 and len(rs.user_ratings(u)) == 4
for bad in [0, 6]:
    try: rs.add_rating(u, mid, bad); raise SystemExit("ожидалась ошибка")
    except ValueError: pass
assert len(rs.rated_by_user(u)) == 4
d = rs.get_movie(mid, u)
assert d["user_rating"] == 4 and "overview_ru" in d and "title_ru" in d and d["imdb_id"].startswith("tt")
assert rs.get_movie(mid)["user_rating"] is None
print("OK, все проверки пройдены")
