
import html
import os

import requests
import streamlit as st

API_URL = os.environ.get("API_URL", "http://127.0.0.1:8000")
COLS = 5

st.set_page_config(page_title="Diamond Films", page_icon="🎬", layout="wide")

st.markdown("""
<style>
  .block-container {padding-top: 2rem; max-width: 1300px;}
  h1, h2, h3 {letter-spacing: .3px;}
  .poster {width: 100%; aspect-ratio: 2/3; border-radius: 12px; overflow: hidden; background: #222;
           box-shadow: 0 6px 18px rgba(0,0,0,.45);}
  .poster img {width: 100%; height: 100%; object-fit: cover; display: block;}
  .poster.ph {display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;
              padding: 12px; background: linear-gradient(160deg, #2b3245, #151821); color: #aab; font-size: .85rem;}
  .poster.ph span {font-size: 2.2rem; margin-bottom: 8px;}
  .mtitle {font-weight: 600; margin: 8px 0 2px; line-height: 1.25; min-height: 2.5em;}
  .mmeta {color: #9aa3b5; font-size: .8rem; line-height: 1.35; min-height: 2.2em;}
  .badge {display: inline-block; background: #f5b301; color: #111; font-weight: 700; border-radius: 6px;
          padding: 1px 7px; font-size: .8rem; margin-right: 6px;}
  .extra {color: #7fd1ae; font-size: .78rem;}
  .hero {background: linear-gradient(120deg, #1d2333, #0e1117); border: 1px solid #262c3b; border-radius: 16px;
         padding: 22px 28px; margin-bottom: 18px;}
  .hero h1 {margin: 0; font-size: 2rem;}
  .hero p {margin: 4px 0 0; color: #9aa3b5;}
</style>
""", unsafe_allow_html=True)


def api_get(path, **params):
    params = {k: v for k, v in params.items() if v not in (None, "")}
    r = requests.get(f"{API_URL}{path}", params=params, timeout=60)
    if r.status_code >= 400:
        raise RuntimeError(r.json().get("detail", r.text) if r.headers.get("content-type", "").startswith("application/json") else r.text)
    return r.json()


def api_post(path, body):
    r = requests.post(f"{API_URL}{path}", json=body, timeout=60)
    if r.status_code >= 400:
        raise RuntimeError(r.json().get("detail", r.text))
    return r.json()


@st.cache_data(ttl=300)
def get_genres():
    return api_get("/genres")


@st.cache_data(ttl=10)
def get_users():
    return api_get("/users")


try:
    api_get("/health")
except Exception:
    st.error(f"Не удаётся подключиться к API ({API_URL}). Сначала запустите его в другом окне терминала:\n\n"
             "`uvicorn api:app --port 8000`")
    st.stop()


users = get_users()
user_by_id = {u["user_id"]: u for u in users}


def create_user_cb():
    name = st.session_state.get("new_user_name", "").strip()
    if not name:
        return
    try:
        u = api_post("/users", {"name": name})
        get_users.clear()
        st.session_state["user_id"] = u["user_id"]
        st.session_state["new_user_name"] = ""
        st.session_state["flash"] = f"Пользователь «{u['name']}» создан. Оцените несколько фильмов, чтобы получить рекомендации."
    except Exception as e:
        st.session_state["flash_err"] = str(e)


with st.sidebar:
    st.markdown("## 🎬 Diamond Films")
    page = st.radio("Раздел", ["🔥 Популярные", "🔍 Поиск и оценка", "🎞 Похожие фильмы",
                               "✨ Для меня", "📚 Мои оценки", "ℹ️ Справка"], label_visibility="collapsed")
    st.divider()
    st.markdown("**Текущий пользователь**")
    uid = st.selectbox("Пользователь", [u["user_id"] for u in users], key="user_id",
                       format_func=lambda i: f"{user_by_id[i]['name']} · {user_by_id[i]['ratings_count']} оц.",
                       label_visibility="collapsed")
    with st.expander("➕ Новый пользователь"):
        st.text_input("Имя", key="new_user_name")
        st.button("Создать", on_click=create_user_cb)

if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))
if "flash_err" in st.session_state:
    st.error(st.session_state.pop("flash_err"))


# ------------------------------------------------------------------- карточки
def rate_cb(key, movie_id):
    rating = st.session_state[f"sl_{key}"]
    try:
        api_post("/ratings", {"user_id": st.session_state["user_id"], "movie_id": movie_id, "rating": rating})
        get_users.clear()
        st.toast(f"Оценка {rating} сохранена в БД ✅")
    except Exception as e:
        st.toast(f"Ошибка: {e}", icon="⚠️")


def open_cb(movie_id):
    st.session_state["open_movie"] = movie_id


def movie_details(movie_id):
    """Окно с карточкой фильма: постер, название (в т.ч. русское), описание на русском, оценка."""
    try:
        m = api_get(f"/movies/{movie_id}", user_id=st.session_state["user_id"])
    except Exception as e:
        st.error(f"Не удалось загрузить фильм: {e}")
        return
    c1, c2 = st.columns([1, 2], gap="large")
    with c1:
        title = html.escape(m["title"])
        if m.get("poster_url"):
            st.markdown(f'<div class="poster"><img src="{html.escape(m["poster_url"])}" alt="{title}"></div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="poster ph"><span>🎬</span>{title}</div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f"### {m['title']}")
        if m.get("title_ru"):
            st.markdown(f"**{m['title_ru']}**")
        genres = ", ".join(g for g in m["genres"].split("|") if g)
        rating_txt = f"★ {m['avg_rating']:.1f} ({m['count_rating']} оценок)" if m["count_rating"] else "оценок пока нет"
        st.caption(f"{m.get('year') or '—'} · {genres or 'жанры не указаны'} · {rating_txt}")
        st.markdown("**Описание**")
        if m.get("overview_ru"):
            st.write(m["overview_ru"])
        elif m.get("overview"):
            st.write(m["overview"])
            st.caption("Русского описания для этого фильма нет - показано оригинальное (английское).")
        else:
            st.caption("Описание для этого фильма отсутствует.")
        st.markdown("**Ваша оценка**" + (f": {m['user_rating']}" if m.get("user_rating") else ""))
        st.select_slider("Оценка", options=[x / 2 for x in range(1, 11)], value=m.get("user_rating") or 4.0,
                         key=f"sl_dlg_{movie_id}", label_visibility="collapsed")
        st.button("Сохранить оценку", key=f"btn_dlg_{movie_id}", on_click=rate_cb, args=(f"dlg_{movie_id}", movie_id))


_dialog = getattr(st, "dialog", None) or getattr(st, "experimental_dialog", None)
if _dialog:
    try:
        show_movie = _dialog("Карточка фильма", width="large")(movie_details)
    except TypeError:                       # старые версии Streamlit без параметра width
        show_movie = _dialog("Карточка фильма")(movie_details)
else:                                       # совсем старый Streamlit: показываем карточку внизу страницы
    show_movie = movie_details


def card(m, key, extra_label=None, show_rate=True):
    title = html.escape(m["title"])
    if m.get("poster_url"):
        st.markdown(f'<div class="poster"><img src="{html.escape(m["poster_url"])}" alt="{title}"></div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="poster ph"><span>🎬</span>{title}</div>', unsafe_allow_html=True)
    genres = ", ".join(g for g in m["genres"].split("|") if g)
    avg = f'<span class="badge">★ {m["avg_rating"]:.1f}</span>' if m["count_rating"] else ""
    st.markdown(f'<div class="mtitle">{title}</div>'
                f'<div class="mmeta">{avg}{m["count_rating"]} оценок<br>{html.escape(genres)}</div>', unsafe_allow_html=True)
    st.button("ℹ️ Подробнее", key=f"info_{key}", on_click=open_cb, args=(m["movie_id"],))
    if extra_label and extra_label in m:
        val = m[extra_label]
        name = {"similarity": "сходство", "score": "соответствие"}.get(extra_label, extra_label)
        st.markdown(f'<div class="extra">{name}: {val:.2f}</div>', unsafe_allow_html=True)
    if m.get("because"):
        st.markdown(f'<div class="extra">похоже на: {html.escape(m["because"])}</div>', unsafe_allow_html=True)
    if m.get("user_rating"):
        st.markdown(f'<div class="extra">Ваша оценка: {m["user_rating"]}</div>', unsafe_allow_html=True)
    if show_rate:
        with st.expander("Оценить"):
            st.select_slider("Оценка", options=[x / 2 for x in range(1, 11)], value=m.get("user_rating") or 4.0,
                             key=f"sl_{key}", label_visibility="collapsed")
            st.button("Сохранить", key=f"btn_{key}", on_click=rate_cb, args=(key, m["movie_id"]))


def grid(items, section, extra_label=None, show_rate=True):
    if not items:
        st.info("Ничего не найдено.")
        return
    for start in range(0, len(items), COLS):
        cols = st.columns(COLS, gap="medium")
        for col, m in zip(cols, items[start:start + COLS]):
            with col:
                card(m, f"{section}_{m['movie_id']}", extra_label, show_rate)


def hero(title, subtitle):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def pick_movie(label, key):
    """Поиск фильма по названию -> выбор из найденных. Возвращает movie_id или None."""
    q = st.text_input(label, key=f"q_{key}", placeholder="например: Matrix, Toy Story, Godfather")
    if not q.strip():
        return None
    found = api_get("/movies/search", q=q, n=15)
    if not found:
        st.warning("Такого фильма нет в базе.")
        return None
    return st.selectbox("Найденные фильмы", [m["movie_id"] for m in found], key=f"sel_{key}",
                        format_func=lambda i: next(m["title"] for m in found if m["movie_id"] == i))


# ------------------------------------------------------------------------ страницы
if page == "🔥 Популярные":
    hero("Популярные фильмы", "Рейтинг учитывает и среднюю оценку, и количество голосов (взвешенная формула IMDb).")
    genre = st.selectbox("Жанр", ["Все жанры"] + get_genres())
    grid(api_get("/popular", n=10, genre=None if genre == "Все жанры" else genre), "pop")

elif page == "🔍 Поиск и оценка":
    hero("Поиск и оценка", "Найдите фильм и поставьте оценку — она сохранится в базе данных и улучшит ваши рекомендации.")
    q = st.text_input("Название фильма", placeholder="например: Inception")
    if q.strip():
        grid(api_get("/movies/search", q=q, n=15), "search")
    else:
        st.caption("Введите название выше.")

elif page == "🎞 Похожие фильмы":
    hero("Похожие фильмы", "Выберите фильм — подберём 10 похожих.")
    method = st.radio("Способ", ["По оценкам пользователей (коллаборативная фильтрация)", "По контенту (описание и жанры)"],
                      horizontal=True)
    mid = pick_movie("Название фильма", "sim")
    if mid:
        path = "cf" if method.startswith("По оценкам") else "content"
        st.markdown("#### Вам понравится, если понравился этот фильм")
        try:
            grid(api_get(f"/movies/{mid}/similar/{path}", n=10), f"sim{path}", "similarity")
        except RuntimeError as e:
            st.warning(str(e))

elif page == "✨ Для меня":
    u = user_by_id[uid]
    hero(f"Рекомендации для: {u['name']}", f"На основе ваших {u['ratings_count']} оценок.")
    method = st.radio("Метод", ["По описанию фильмов", "Гибридный (описание + оценки других)",
                                "По пользователям с похожим вкусом"], horizontal=True)
    try:
        if method.startswith("По пользователям"):
            grid(api_get(f"/users/{uid}/recommendations/user-cf", n=10), "mecf", "score")
        else:
            res = api_get(f"/users/{uid}/recommendations", n=10, method="content" if method.startswith("По описанию") else "hybrid")
            if res["method"] == "popular":
                st.info("У вас пока нет оценок, поэтому показаны популярные фильмы. Оцените несколько фильмов в разделе «Поиск и оценка».")
            elif res["method"] == "content":
                st.caption("Подобрано по сюжету: сравниваем описания фильмов, которые вам понравились (оценка ≥ 4), с описаниями остальных.")
            grid(res["items"], "me", "score" if res["method"] != "popular" else None)
    except RuntimeError as e:
        st.warning(str(e))

elif page == "📚 Мои оценки":
    u = user_by_id[uid]
    hero("Мои оценки", f"Пользователь: {u['name']}")
    rated = api_get(f"/users/{uid}/ratings")
    if not rated:
        st.info("Вы ещё ничего не оценили.")
    else:
        titles = {m["movie_id"]: m["title"] for m in rated}
        st.caption(f"Всего оценок: {len(rated)} - показаны все, список прокручивается колёсиком.")
        st.dataframe(
            [{"Фильм": m["title"], "Моя оценка": m["user_rating"],
              "Год": str(m["year"]) if m["year"] else "",
              "Жанры": m["genres"].replace("|", ", "),
              "Средняя по залу": m["avg_rating"], "Голосов": m["count_rating"]} for m in rated],
            hide_index=True, width="stretch", height=min(600, 40 + 35 * len(rated)))
        mid = st.selectbox("Фильм из списка выше", list(titles), format_func=titles.get)
        st.button("Изменить оценку", on_click=open_cb, args=(mid,))

else:
    hero("Справка", "Что умеет приложение и какие команды есть у API.")
    st.markdown("""
**Как пользоваться**
1. Выберите пользователя слева (или создайте нового). На любой карточке фильма кнопка **«Подробнее»** открывает окно с описанием на русском.
2. **Популярные** - топ-10 фильмов, можно фильтровать по жанру.
3. **Поиск и оценка** - найдите фильм, раскройте «Оценить», выберите оценку от 0.5 до 5 и нажмите «Сохранить». Оценка записывается в БД.
4. **Похожие фильмы** - выберите фильм и способ: по оценкам других пользователей или по контенту (жанры).
5. **Для меня** - персональные рекомендации: по описанию фильмов, которые вам понравились (основной способ), гибридные или по пользователям с похожим вкусом.
6. **Мои оценки** - всё, что вы уже оценили.
""")
    st.markdown("#### Команды API")
    st.caption(f"Адрес API: {API_URL} · интерактивная документация: {API_URL}/docs")
    cmds = api_get("/help")
    st.dataframe(
        [{"Метод": c["method"], "Путь": c["path"], "Параметры": c["params"], "Описание": c["description"]} for c in cmds],
        hide_index=True)
    st.markdown("""
**Методы рекомендаций**
- *Популярность* - взвешенный рейтинг: фильм с одной оценкой «5» не обгонит фильм с сотнями оценок «4.5».
- *Коллаборативная по фильмам* - похожими считаются фильмы, которые оценивают одни и те же люди.
- *Коллаборативная по пользователям* - берём людей со схожим вкусом и рекомендуем то, что им понравилось.
- *По контенту* - похожее описание сюжета и жанры (TF-IDF).
- *Персональные по описанию* - из описаний фильмов, которые вам понравились (оценка >= 4), строится профиль вкуса; рекомендуем фильмы с самым близким описанием и показываем, на какой ваш любимый фильм каждый похож.\n- *Гибрид* - сочетание описания и коллаборативной фильтрации.
""")


# --------------------------------------------- окно с карточкой фильма (после кнопки «Подробнее»)
_open = st.session_state.pop("open_movie", None)
if _open:
    show_movie(_open)
