"""FastAPI-интерфейс рекомендательной системы фильмов (задание 4.1).
Запуск:  uvicorn api:app --reload --port 8000
"""
import os
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from recsys import NotEnoughData, Recommender

DB_PATH = os.environ.get("FILMS_DB", os.path.join(os.path.dirname(__file__), "data", "films.db"))

app = FastAPI(
    title="Film Recommender API",
    version="1.0",
    description="Рекомендательная система фильмов: популярные, коллаборативная фильтрация "
                "(по пользователям и по фильмам), рекомендации по контенту, персональные рекомендации.",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
rs = Recommender(DB_PATH)


class RatingIn(BaseModel):
    user_id: int
    movie_id: int
    rating: float = Field(..., ge=0.5, le=5, description="Оценка от 0.5 до 5 (шаг 0.5)")


class UserIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)


def _call(fn, *args, **kwargs):
    """Переводит исключения модели в корректные HTTP-ответы."""
    try:
        return fn(*args, **kwargs)
    except KeyError as e:
        raise HTTPException(404, f"Не найдено: {e.args[0]}")
    except NotEnoughData as e:
        raise HTTPException(422, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/health", tags=["service"], summary="Проверка, что API работает")
def health():
    return {"status": "ok"}


@app.get("/popular", tags=["1. Популярные"], summary="Топ популярных фильмов (взвешенный рейтинг IMDb)")
def popular(n: int = Query(10, ge=1, le=50, description="сколько фильмов"),
            genre: Optional[str] = Query(None, description="жанр, например Comedy")):
    return rs.popular(n, genre)


@app.get("/genres", tags=["1. Популярные"], summary="Список жанров")
def genres():
    return rs.genres()


@app.get("/movies/search", tags=["Фильмы"], summary="Поиск фильма по части названия")
def search(q: str = Query("", description="часть названия"), n: int = Query(20, ge=1, le=100)):
    return rs.search(q, n)


@app.get("/movies/{movie_id}", tags=["Фильмы"], summary="Карточка фильма: описание (на русском), русское название, оценка пользователя")
def movie(movie_id: int, user_id: Optional[int] = Query(None, description="если указан — вернёт и оценку этого пользователя")):
    return _call(rs.get_movie, movie_id, user_id)


@app.get("/movies/{movie_id}/similar/cf", tags=["2. Коллаборативная фильтрация"],
         summary="Похожие фильмы (по фильмам, item-based CF): их оценивают так же")
def similar_cf(movie_id: int, n: int = Query(10, ge=1, le=50)):
    return _call(rs.similar_cf, movie_id, n)


@app.get("/users/{user_id}/recommendations/user-cf", tags=["2. Коллаборативная фильтрация"],
         summary="Рекомендации по пользователям (user-based CF): что нравится людям с похожим вкусом")
def recommend_user_cf(user_id: int, n: int = Query(10, ge=1, le=50), k: int = Query(30, ge=5, le=200, description="число соседей")):
    return _call(rs.recommend_user_cf, user_id, n, k)



@app.get("/movies/{movie_id}/similar/content", tags=["3. По контенту"],
         summary="10 рекомендованных фильмов по контенту (описание + жанры, TF-IDF)")
def similar_content(movie_id: int, n: int = Query(10, ge=1, le=50)):
    return _call(rs.similar_content, movie_id, n)

@app.get("/users/{user_id}/recommendations", tags=["4. Персональные"],
         summary="Персональные рекомендации: по ОПИСАНИЮ понравившихся фильмов (content) или гибрид с CF; без оценок — популярные")
def personal(user_id: int, n: int = Query(10, ge=1, le=50),
             method: Literal["content", "hybrid"] = Query("content", description="content — по описанию (по умолчанию); hybrid — описание + коллаборативная фильтрация"),
             alpha: float = Query(0.7, ge=0, le=1, description="для hybrid: вес CF (остальное — описание)")):
    return _call(rs.recommend_personal, user_id, n, method, alpha)


@app.get("/users", tags=["Пользователи и оценки"], summary="Список пользователей")
def users():
    return rs.list_users()


@app.post("/users", tags=["Пользователи и оценки"], summary="Создать пользователя", status_code=201)
def create_user(body: UserIn):
    return _call(rs.create_user, body.name)


@app.get("/users/{user_id}/ratings", tags=["Пользователи и оценки"], summary="Оценки пользователя")
def user_ratings(user_id: int):
    return _call(rs.rated_by_user, user_id)


@app.post("/ratings", tags=["Пользователи и оценки"],
          summary="Оценить фильм (сохраняется в БД; повторная оценка обновляет прежнюю)")
def rate(body: RatingIn):
    return _call(rs.add_rating, body.user_id, body.movie_id, body.rating)


COMMANDS = [
    {"method": "GET", "path": "/popular", "params": "n=10, genre=Comedy", "description": "Топ популярных фильмов (по жанру — опционально)"},
    {"method": "GET", "path": "/genres", "params": "—", "description": "Список жанров"},
    {"method": "GET", "path": "/movies/search", "params": "q, n=20", "description": "Поиск по названию"},
    {"method": "GET", "path": "/movies/{movie_id}", "params": "user_id (необязательно)", "description": "Карточка фильма с описанием на русском"},
    {"method": "GET", "path": "/movies/{movie_id}/similar/cf", "params": "n=10", "description": "Похожие по оценкам пользователей (item-based CF)"},
    {"method": "GET", "path": "/movies/{movie_id}/similar/content", "params": "n=10", "description": "Похожие по контенту (описание фильма и жанры)"},
    {"method": "GET", "path": "/users/{user_id}/recommendations/user-cf", "params": "n=10, k=30", "description": "Рекомендации по пользователям (user-based CF)"},
    {"method": "GET", "path": "/users/{user_id}/recommendations", "params": "n=10, method=content|hybrid, alpha=0.7", "description": "Персональные рекомендации: по описанию понравившихся фильмов (по умолчанию) или гибрид"},
    {"method": "GET", "path": "/users", "params": "—", "description": "Список пользователей"},
    {"method": "POST", "path": "/users", "params": "{name}", "description": "Создать пользователя"},
    {"method": "GET", "path": "/users/{user_id}/ratings", "params": "—", "description": "Оценки пользователя"},
    {"method": "POST", "path": "/ratings", "params": "{user_id, movie_id, rating 0.5–5}", "description": "Оценить фильм (запись в БД)"},
]


@app.get("/help", tags=["service"], summary="Справка по командам API и их параметрам")
def help_commands():
    return COMMANDS
