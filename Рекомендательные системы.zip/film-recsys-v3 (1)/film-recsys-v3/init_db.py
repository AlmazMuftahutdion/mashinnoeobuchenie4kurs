import argparse
import glob
import os
import sqlite3

import pandas as pd

SCHEMA = """
DROP TABLE IF EXISTS ratings;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS movies;

CREATE TABLE movies (
    movie_id   INTEGER PRIMARY KEY,
    imdb_id    TEXT,
    tmdb_id    INTEGER,
    title      TEXT NOT NULL,
    year       INTEGER,
    genres     TEXT NOT NULL DEFAULT '',
    poster_url TEXT NOT NULL DEFAULT '',
    overview   TEXT NOT NULL DEFAULT '',
    overview_ru TEXT NOT NULL DEFAULT '',
    title_ru   TEXT NOT NULL DEFAULT ''
);
CREATE TABLE users (
    user_id    INTEGER PRIMARY KEY,
    name       TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE ratings (
    user_id  INTEGER NOT NULL REFERENCES users(user_id),
    movie_id INTEGER NOT NULL REFERENCES movies(movie_id),
    rating   REAL    NOT NULL CHECK (rating >= 0.5 AND rating <= 5),
    ts       INTEGER,
    PRIMARY KEY (user_id, movie_id)
);
CREATE INDEX idx_ratings_movie ON ratings(movie_id);
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--db", default=os.path.join("data", "films.db"))
    a = ap.parse_args()

    movies = pd.read_csv(os.path.join(a.data_dir, "movies.csv"))
    photo = pd.read_csv(os.path.join(a.data_dir, "photo.csv"))
    rfile = sorted(glob.glob(os.path.join(a.data_dir, "rating*.csv")))[0]
    ratings = pd.read_csv(rfile)
    print("Файл оценок:", rfile)

    for col in ("overview", "overview_ru", "title_ru"): 
        if col not in photo:
            photo[col] = ""
    text_cols = ["poster_url", "overview", "overview_ru", "title_ru"]
    movies = movies.merge(photo[["movieId"] + text_cols], on="movieId", how="left")
    for col in text_cols:
        movies[col] = movies[col].fillna("")
    movies["genres"] = movies["genres"].replace("(no genres listed)", "").fillna("")
    movies["year"] = movies["year"].astype("Int64")
    movies["tmdbId"] = movies["tmdbId"].astype("Int64")
    movies = movies.rename(columns={"movieId": "movie_id", "imdbId": "imdb_id", "tmdbId": "tmdb_id"})
    movies = movies[["movie_id", "imdb_id", "tmdb_id", "title", "year", "genres", "poster_url", "overview", "overview_ru", "title_ru"]]

    ratings = ratings.drop_duplicates(["userId", "movieId"]).rename(
        columns={"userId": "user_id", "movieId": "movie_id", "timestamp": "ts"})
    ratings = ratings[ratings.movie_id.isin(movies.movie_id)]
    users = pd.DataFrame({"user_id": sorted(ratings.user_id.unique())})
    users["name"] = "Пользователь " + users.user_id.astype(str)

    os.makedirs(os.path.dirname(a.db) or ".", exist_ok=True)
    con = sqlite3.connect(a.db)
    con.executescript(SCHEMA)
    movies.astype(object).where(movies.notna(), None).to_sql("movies", con, if_exists="append", index=False)
    users.to_sql("users", con, if_exists="append", index=False)
    ratings[["user_id", "movie_id", "rating", "ts"]].to_sql("ratings", con, if_exists="append", index=False)
    con.commit()
    for t in ("movies", "users", "ratings"):
        print(t, con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
    print("с постерами:", con.execute("SELECT COUNT(*) FROM movies WHERE poster_url != ''").fetchone()[0])
    print("с описанием (EN):", con.execute("SELECT COUNT(*) FROM movies WHERE overview != ''").fetchone()[0])
    print("с описанием (RU):", con.execute("SELECT COUNT(*) FROM movies WHERE overview_ru != ''").fetchone()[0])
    con.close()
    print("Готово:", a.db)


if __name__ == "__main__":
    main()
