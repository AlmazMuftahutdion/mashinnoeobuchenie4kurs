# Рекомендательная система фильмов (задания 4.1 и 4.2)

Python · SQLite · FastAPI (API) · Streamlit (приложение) · scikit-learn

## Структура
| Файл | Назначение |
|---|---|
| `init_db.py` | создаёт БД `data/films.db` из CSV (movies, ratings, photo) |
| `recsys.py` | рекомендательная система (читает/пишет SQLite) |
| `api.py` | **4.1** FastAPI: 12 эндпоинтов, справка `/help`, Swagger `/docs` |
| `app.py` | **4.2** приложение Streamlit, работает только через API |
| `test_recsys.py` | автоматические проверки модели и записи оценок в БД |
| `run.bat` | запуск всего одним кликом (Windows) |

## Установка и запуск
```
pip install -r requirements.txt
```
1. Положите в папку `data/` три файла: `movies.csv`, файл оценок (`ratings.csv` или `ratings (1).csv`) и `photo.csv` **с постерами и описаниями** (после `get_posters.py`; в нём есть русские описания и названия).
2. Создайте БД: `py init_db.py`
3. Запустите API: `py -m uvicorn api:app --port 8000`  (документация: http://127.0.0.1:8000/docs)
4. В другом окне: `py -m streamlit run app.py`  (откроется http://localhost:8501)

Либо просто запустите `run.bat`.
Если поменяли CSV (например, добавили постеры) - снова выполните `py init_db.py` (БД пересоздаётся, **новые оценки из приложения при этом сотрутся**).

## Соответствие заданию
| Требование | Реализация |
|---|---|
| 4.1.1 Топ-10 популярных | `GET /popular` (взвешенный рейтинг IMDb, фильтр по жанру) |
| 4.1.2 Коллаборативная фильтрация | по фильмам: `GET /movies/{id}/similar/cf`; по пользователям: `GET /users/{id}/recommendations/user-cf` |
| 4.1.3 10 рекомендаций по контенту | `GET /movies/{id}/similar/content` (TF-IDF: описание сюжета + жанры) |
| 4.1.4 Персональные рекомендации | `GET /users/{id}/recommendations` (по умолчанию `method=content` - по описанию понравившихся фильмов; `method=hybrid` - с CF) |
| 4.2 GUI на основе API | `app.py` (Streamlit) |
| БД, оценка фильма сохраняется | SQLite, `POST /ratings` > таблица `ratings` |
| Карточка фильма с описанием на русском | кнопка «Подробнее» на карточке > окно; `GET /movies/{id}` |
| Справка по командам и параметрам | раздел «Справка» в приложении, `GET /help`, `/docs` |

## База данных
`movies(movie_id, imdb_id, tmdb_id, title, year, genres, poster_url, overview, overview_ru, title_ru)` ·
`users(user_id, name, created_at)` ·
`ratings(user_id, movie_id, rating, ts)`, PK `(user_id, movie_id)` - повторная оценка обновляет прежнюю.
После новой оценки модель автоматически пересобирается при следующем запросе рекомендаций.
